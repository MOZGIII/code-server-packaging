---
name: Extension Bug
about: Report problems and unexpected behavior with extensions.
title: ''
labels: 'extension-specific'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->

- `code-server` version: <!-- The version of code-server -->
- OS Version: <!-- OS version, cloud provider,  -->
- Extension: <!-- Link to extension -->

## Description

<!-- Describes the problem here -->

## Steps to Reproduce

1. <!-- step 1: click ... -->
1. <!-- step 2: ... -->