import * as packageJson from "../../../../lib/vscode/package.json";
export default { name: "vscode", version: packageJson.version };
