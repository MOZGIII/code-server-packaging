class Watchdog {
	public start(): void {
		// No action required.
	}
}

export = new Watchdog();
