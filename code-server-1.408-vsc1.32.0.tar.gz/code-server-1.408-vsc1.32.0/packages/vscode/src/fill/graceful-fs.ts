export const gracefulify = (): void => undefined;

export * from "fs";
