# ide-api

Provides window listeners for interfacing with the IDE.

Created for content-scripts.