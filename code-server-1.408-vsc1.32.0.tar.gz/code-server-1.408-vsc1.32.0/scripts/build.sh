#!/bin/bash
set -e

yarn task build:server:binary
