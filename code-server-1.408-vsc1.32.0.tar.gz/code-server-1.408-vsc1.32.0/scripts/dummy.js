// This is for ignoring CSS and images when running tests with Jest.
